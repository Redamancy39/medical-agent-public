"""Bounded original context for retrieved medical chunks; never modifies the KB."""
from copy import deepcopy
import hashlib
import re

from .medical_quality import check_anchor, source_catalog


def expand_medical_evidence(documents, catalog=None):
    result = deepcopy(documents)
    if catalog is None:
        if not any(str(d.get('document_id', '')).startswith('nlm-') for d in result): return result
        catalog = source_catalog()
    for doc in result:
        original = catalog.get(doc.get('document_id'))
        if original is None: continue
        start, end = doc.get('start'), doc.get('end')
        if (doc.get('source_sha256') != original['source_sha256']
                or hashlib.sha256(original['raw'].encode()).hexdigest() != original['source_sha256']
                or doc.get('version') != original['editorial_version']
                or type(start) is not int or type(end) is not int
                or not 0 <= start < end <= len(original['editorial_text'])
                or doc.get('content') != original['editorial_text'][start:end]):
            raise ValueError('SOURCE_CONTEXT_VERSION_INVALID')
        spans = doc.setdefault('source_spans', [])
        for span in spans:
            check_anchor({**span, 'document_id': doc['document_id'],
                'source_sha256': doc['source_sha256']}, catalog)
        paragraphs = list(re.finditer(r'[^\n]+(?:\n(?!\n)[^\n]+)*', original['raw']))
        wanted = []
        for span in list(spans):
            for i, paragraph in enumerate(paragraphs):
                if not paragraph.start() <= span['start'] < paragraph.end(): continue
                wanted.append(paragraph)
                # The section introduction often states the measured quantity/time
                # while the retrieved anchor only names a later use or exception.
                heading = next((j for j in range(i, -1, -1)
                    if paragraphs[j].group().strip().endswith('?')), None)
                if heading is not None and heading+1 < len(paragraphs): wanted.append(paragraphs[heading+1])
                break
        used = 0
        for paragraph in wanted:
            span = {'start': paragraph.start(), 'end': paragraph.end(), 'quote': paragraph.group()}
            if span in spans or len(span['quote']) > 1800: continue
            if len(spans) >= 10 or used+len(span['quote']) > 2400: continue
            spans.append(span); used += len(span['quote'])
    return result
