"""Narrow Chinese safety-policy triggers, not a diagnostic triage model."""
import re

URGENT_MESSAGE = ('【安全提示｜规则触发】你描述了可能需要立即医疗帮助的严重症状。'
    '请立即联系当地急救服务或急诊，不等待本系统检索或多Agent讨论。'
    '意识不清时不要经口喂食、喂水或给药。这里无法确定病因、确诊或调整用药；请遵从急救人员指导。')


def urgent_policy_trigger(question):
    # Definition-only requests and explicitly negated symptom clauses are not current risk reports.
    if (re.match(r'^(?:请)?(?:解释|介绍|比较|什么是|为什么|如何识别)', question.strip())
            and not re.search(r'我|现在|患者|场景|刚|用降糖药后', question)): return False
    clauses = re.split(r'[，,。；;\n]', question)
    positive = ' '.join(c for c in clauses if not re.search(r'没有|未出现|未发生|否认|不伴|无(?:明显)?(?:胸痛|呼吸困难|昏厥|抽搐)', c))
    pressure = re.search(r'血压\s*(\d{2,3})\s*[/／]\s*(\d{2,3})', positive)
    high_with_symptom = (pressure and (int(pressure[1]) > 180 or int(pressure[2]) > 120)
                         and re.search(r'胸痛|呼吸困难', positive))
    unconscious = re.search(r'昏厥|意识不清|失去意识', positive)
    seizure_context = re.search(r'抽搐|降糖药|低血糖', positive)
    return bool(high_with_symptom or (unconscious and seizure_context))
