"""Narrow Chinese safety-policy triggers, not a diagnostic triage model."""
import re

URGENT_MESSAGE = ('【安全提示｜规则触发】你描述了可能需要立即医疗帮助的严重症状。'
    '请立即联系当地急救服务或急诊，不等待本系统检索或多Agent讨论。'
    '意识不清时不要经口喂食、喂水或给药。这里无法确定病因、确诊或调整用药；请遵从急救人员指导。')


def urgent_policy_trigger(question):
    # Definition-only requests and explicitly negated symptom clauses are not current risk reports.
    if (re.match(r'^(?:请)?(?:解释|介绍|比较|什么是|为什么|如何识别)', question.strip())
            and not re.search(r'我|现在|患者|场景|刚|用降糖药后', question)): return False
    # Remove negated symptoms, not whole clauses: "没有缓解" is ongoing pain.
    symptoms = r'(?:胸痛|胸口(?:疼)?痛|呼吸困难|昏厥|抽搐|意识不清|失去意识|大汗|冷汗)'
    positive = re.sub(r'(?:没有|未出现|未发生|否认|不伴|无)(?:明显)?' + symptoms +
        r'(?:[和或及、]' + symptoms + r')*', '', question)
    pressure = re.search(r'血压\s*(\d{2,3})\s*[/／]\s*(\d{2,3})', positive)
    high_with_symptom = (pressure and (int(pressure[1]) > 180 or int(pressure[2]) > 120)
                         and re.search(r'胸痛|呼吸困难', positive))
    unconscious = re.search(r'昏厥|意识不清|失去意识', positive)
    seizure_context = re.search(r'抽搐|降糖药|低血糖', positive)
    # Existing urgent text only advises immediate help; this rule does not diagnose
    # or add medication instructions. Source: https://www.nhs.uk/symptoms/chest-pain/
    historical_resolved = re.search(r'去年|上周|以前|既往|昨天', question) and re.search(
        r'(?:现在|目前)(?:已)?(?:没有症状|无症状|无不适|已缓解)', question)
    chest_pain = re.search(r'胸痛|胸口[^，,。；;\n]{0,20}(?:疼痛|绞痛|痛)', positive)
    concerning = re.search(r'大汗|冷汗|呼吸困难|持续[^，,。；;\n]{0,12}不缓解|(?:没有|未)缓解', positive)
    current_context = re.search(r'我|父亲|母亲|家人|患者|有人|现在|突然|刚|场景', question)
    chest_urgent = chest_pain and concerning and current_context and not historical_resolved
    return bool(high_with_symptom or (unconscious and seizure_context) or chest_urgent)
